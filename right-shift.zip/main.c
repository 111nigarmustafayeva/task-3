/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>

int main(){
   int arr[40],n;
   printf("size daxil edin:");
   scanf("%d",&n);
   printf("\narray-in elementlerini daxil edin :");
   for(int i=0;i < n;i++){
       scanf("%d",&arr[i]);
   }
   
   int k,j,i;
   printf("\nsurusme ededini dexil edin :");
   scanf("%d",&k);
   for(j=1;j <= k;j++){
       int soneded=arr[n-1];
       for(i=n-1;i >= 1;i--){
        arr[i]=arr[i-1];   
       }
       arr[i]=soneded;
       }
   for(int i=0;i < n;i++){
       printf("%d\n",arr[i]);
   }
   return 0;
}
